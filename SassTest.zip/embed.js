function createIframe(settings) {
  var regex = /(http).*?(\/\/)/g; //regex to remove first part of domain
  var regex2 = /\/.*/g; //regex to remove path from domain
  var url = window.location.href; //get the url
  var domain = url.replace(regex,''); //remove http
  var cleandomain = domain.replace(regex2,''); //remove page and spit out clean url
  var findomain = cleandomain.replace(/\./g,'-');

	var iframe = document.createElement("iframe"); //Create an iframe
	iframe.src="//localhost/"+settings.path; //Set the iframe source switched to localhost for testing
	iframe.src=iframe.src+"?referrer="+findomain;
	iframe.height=settings.height; //Set the iframe height
	iframe.width=settings.width; //Set the iframe width
	iframe.setAttribute("frameborder","0"); //Remove borders (better to add a border inside the iframe so we control styling)
	iframe.setAttribute("scrolling", settings.scrolling); //Set scroll settings
	return(iframe);
}

var config = { //Object containing the config of all available tools
	targetSelector: "stepchange-tool", //The class name used in the code on the 3rd party sites
	tools: {
		danger_signs_tool: { //Danger signs of debt test
			path:"dsd", //Location on server
			width:"100%", //Required width of tool (use % for responsive)
			height:"700", //Required height of tool
			scrolling:"no",
		},
		dev_danger_signs_tool: { //Danger signs of debt test
			path:"dev-dsd", //Location on server
			width:"100%", //Required width of tool (use % for responsive)
			height:"700", //Required height of tool
			scrolling:"no",
		}
	}
}

var items = document.querySelectorAll('.'+config.targetSelector) //Get all occurrences of class 'stepchange-tool' on the page
for(var i=0;i<=items.length-1;i++) { //Loop through
	var node=items[i];
	if(config.tools[node.id] != undefined) {  //If there is a tool with this name
		node.parentNode.replaceChild(createIframe(config.tools[node.id]),node);  //Replace the stepchange-tool node with the iframe
	}
}
